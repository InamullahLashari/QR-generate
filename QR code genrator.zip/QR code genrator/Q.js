const input = document.querySelector("#input");
const image = document.querySelector("#Qrimg");
const btn = document.querySelector("#generateBtn");

btn.addEventListener("click", () => {
    if (input.value.length > 0) { // Fixed typo: 'lenght' to 'length'
        // Generate the QR code URL based on the input value
        image.src = "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=" + encodeURIComponent(input.value);
        image.classList.add("show-img"); // Assuming you have CSS for showing the image
    } else {
        input.classList.add('error'); // Assuming you have CSS for error styling
        setTimeout(() => {
            input.classList.remove('error');
        }, 1000);
    }
});
